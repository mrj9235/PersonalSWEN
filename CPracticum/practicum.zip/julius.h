#ifndef JULIUS_H_
#define JULIUS_H_

#define MAXLINESIZE 20

// Do NOT modify the following functions declarations or the number or type of parameters below:
void julius(char string[]);
int readline(char s[], int lim);
char encipher(char c);

#endif
